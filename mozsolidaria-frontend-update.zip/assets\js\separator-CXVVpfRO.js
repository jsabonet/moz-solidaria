import{t as y,r as s,j as l,ar as d,ax as v}from"./index-dP8hqHPH.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=y("Hash",[["line",{x1:"4",x2:"20",y1:"9",y2:"9",key:"4lhtct"}],["line",{x1:"4",x2:"20",y1:"15",y2:"15",key:"vyu0kd"}],["line",{x1:"10",x2:"8",y1:"3",y2:"21",key:"1ggp8o"}],["line",{x1:"16",x2:"14",y1:"3",y2:"21",key:"weycgp"}]]);var h="Separator",n="horizontal",m=["horizontal","vertical"],c=s.forwardRef((a,r)=>{const{decorative:t,orientation:o=n,...e}=a,i=u(o)?o:n,x=t?{role:"none"}:{"aria-orientation":i==="vertical"?i:void 0,role:"separator"};return l.jsx(d.div,{"data-orientation":i,...x,...e,ref:r})});c.displayName=h;function u(a){return m.includes(a)}var p=c;const f=s.forwardRef(({className:a,orientation:r="horizontal",decorative:t=!0,...o},e)=>l.jsx(p,{ref:e,decorative:t,orientation:r,className:v("shrink-0 bg-border",r==="horizontal"?"h-[1px] w-full":"h-full w-[1px]",a),...o}));f.displayName=p.displayName;export{k as H,f as S};
